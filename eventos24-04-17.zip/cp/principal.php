<?php	
$logo = '<link rel="icon" type="image/png" href="'.$link.'imagenes/logo2.png" />';
?>
