<aside>
  <div class="aside">
    <form class="navbar-form navbar-right hidden-xs hidden-md hidden-lg" role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Buscar">
      </div>
      <button type="submit" class="btn btn-default">Enviar
      </button>
    </form>
    <div class="dropdown tutoriales">
      <button href="#" class="dropdown-toggle btn btn-default" data-toggle="dropdown">
          Tutoriales <b class="caret"></b>
      </button>
      <ul class="dropdown-menu">
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-eye-open"></span> ver los eventos</a>
        </li>
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-filter"></span> buscar eventos</a>
        </li>
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-plus"></span> como crear un usuario</a>
        </li>
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-user"></span> como loguearme</a>
        </li>
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-usd"></span> compras en eventos</a>
        </li>
        <li>
          <a href="<?= $link; ?>" class=""><span class="glyphicon glyphicon-briefcase"></span> contratacion</a>
        </li>
      </ul>
    </div>
  </div>
<div id="fb-root"></div>
<div class="fb-page" data-href="https://www.facebook.com/AlcaldiadeGirardot" data-height="800" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/AlcaldiadeGirardot" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/AlcaldiadeGirardot">Alcaldía de Girardot</a></blockquote></div>
</aside>

   