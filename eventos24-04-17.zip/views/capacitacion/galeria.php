<?php
 $link="../../";
?>
<link rel="stylesheet" href="<?= $link; ?>/librerias/galeria/css/smoothbox.css">
	

		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/1.jpg" title="CLickea Aqui para ver la Historieta"><img src="<?= $link; ?>imagenes/policia/historieta/1.jpg" width="100%"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/2.png"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/3.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/4.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/5.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/6.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/7.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/8.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/9.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/10.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/11.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/12.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/13.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/14.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/15.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/16.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/17.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/18.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/19.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/20.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/21.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/22.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/23.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/24.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/25.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/26.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/27.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/28.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/29.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/30.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/31.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/32.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/33.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/34.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/35.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/36.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/37.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/38.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/39.jpg"></a>
			<a class="sb" href="<?= $link; ?>imagenes/policia/historieta/40.jpg"></a>
		</div>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.js"></script>
<script type="text/javascript" src="<?= $link; ?>/librerias/galeria/js/smoothbox.min.js"></script>